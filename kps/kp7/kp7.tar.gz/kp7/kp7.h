#pragma once 
#include <stdbool.h>
#include "vector/vector_dbl.h"
#include "vector/vector_int.h"
#include "vector/vector_mx.h"

typedef struct {
    int n, m;
    int_vector row;
    mx_vector elems;
    dbl_mx_el max_el;
    int prev_clmn_max_el;
} matrix;

matrix read_mtx();
void print_mtx(matrix *mx);
void kp7_var2(matrix *mx);
