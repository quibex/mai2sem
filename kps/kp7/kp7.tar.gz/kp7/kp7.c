#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include "kp7.h"


matrix read_mtx(){
    int n, m;
    scanf("%d%d", &n, &m);
    matrix mx;
    mx.n = n;
    mx.m = m;
    mx.max_el.val = -1;
    mx.prev_clmn_max_el = -1;
    int_init(&mx.row);
    mx_init(&mx.elems);

    for (int i = 0; i < n; i++){
        bool row_empty = true;
        for (int j = 0; j < m; j++){
            double num;
            scanf("%lf", &num);
            if (num != 0){
                if (row_empty){
                    row_empty = false;
                    int_push_back(&mx.row, mx_get_size(&mx.elems));
                } else {
                    dbl_mx_el prev_el = mx_pop_back(&mx.elems);
                    prev_el.next_el_idx = mx_get_size(&mx.elems) + 1;
                    mx_push_back(&mx.elems, prev_el);
                }
                dbl_mx_el el;
                el.clmn = j;
                el.val = num;
                el.next_el_idx = 0;
                mx_push_back(&mx.elems, el);
                if (fabs(el.val) == fabs(mx.max_el.val)) mx.prev_clmn_max_el = mx.max_el.clmn;
                if (fabs(el.val) >= fabs(mx.max_el.val)) mx.max_el = el;
            }
        }
        if (row_empty){
            int_push_back(&mx.row, -1);
        }
    }
    return mx;
}

void print_mtx(matrix *mx){
    for (int i = 0; i < mx->n; i++){
        int elem_idx = int_get_el(&mx->row, i);
        dbl_mx_el elem = mx_get_el(&mx->elems, elem_idx);
        for (int j = 0; j < mx->m; j++){
            if (elem.clmn == j){
                printf("%lf ", mx_get_el(&mx->elems, elem_idx).val);
                elem_idx = elem.next_el_idx;
                elem = mx_get_el(&mx->elems, elem_idx);
            } else {
                printf("0.000000 ");
            }
        }
        printf("\n");
    }
}

void kp7_var2(matrix *mx){
    for (int i = 0; i < mx->n; i++){
        int elem_idx = int_get_el(&mx->row, i);
        dbl_mx_el elem = mx_get_el(&mx->elems, elem_idx);
        int changeable_clmn = mx->max_el.clmn;
        if (mx->prev_clmn_max_el != -1) changeable_clmn = mx->prev_clmn_max_el;
        for (int j = 0; j < mx->m; j++){
            if (changeable_clmn == elem.clmn){
                dbl_mx_el new_el = mx_get_el(&mx->elems, elem_idx);
                new_el.val /= mx->max_el.val;
                mx_set_el(&mx->elems, elem_idx, new_el);
            }
            elem_idx = elem.next_el_idx;
            elem = mx_get_el(&mx->elems, elem_idx);
        }
    }
}



