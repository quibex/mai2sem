#pragma once 

int file_to_bin(const char* input_file, const char* output_file);