
enum MAAMG {
    MICROSOFT = 0,
    APPLE = 1,
    AMAZON = 2,
    META = 3,
    GOOGLE = 4
};

int get_enum_id(char company[10]);
char* get_company_name(int id);