
#include <string.h>
#include "enummaamg.h"

int get_enum_id(char company[10]){
    if ((strcmp(company, "MICROSOFT") == 0) || (strcmp(company, "Microsoft") == 0) || (strcmp(company, "microsoft") == 0)) return MICROSOFT;
    if ((strcmp(company, "APPLE") == 0) || (strcmp(company, "Apple") == 0) || (strcmp(company, "apple") == 0)) return APPLE;
    if ((strcmp(company, "AMAZON") == 0) || (strcmp(company, "Amazon") == 0)  || (strcmp(company, "amazon") == 0)) return AMAZON;
    if ((strcmp(company, "META") == 0) || (strcmp(company, "Meta") == 0) || (strcmp(company, "meta") == 0)) return META;
    if ((strcmp(company, "GOOGLE") == 0) || (strcmp(company, "Google") == 0)  || (strcmp(company, "google") == 0)) return GOOGLE;
    return -1;
}

char* get_company_name(int id){
    if (id == MICROSOFT) return "MICROSOFT";
    if (id == APPLE) return "APPLE";
    if (id == AMAZON) return "AMAZON";
    if (id == META) return "META";
    if (id == GOOGLE) return "GOOGLE";
    return "err";
}